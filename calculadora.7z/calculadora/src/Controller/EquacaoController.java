/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Calculadora;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class EquacaoController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField a;

    @FXML
    private TextField b;

    @FXML
    private TextField c;

    @FXML
    private TextField x1;

    @FXML
    private Button btsair;

    @FXML
    private TextField x2;

    @FXML
    private Button btcalc;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btcalc.setOnMouseClicked((MouseEvent evt) -> {

            Calculadora ca = new Calculadora();

            double ab = Double.parseDouble(a.getText());
            double bb = Double.parseDouble(b.getText());
            double cb = Double.parseDouble(c.getText());

            double answer1 = (-bb + Math.sqrt(Math.pow(bb, 2) - (4 * ab * cb))) / (2 * ab);
            double answer2 = (-bb - Math.sqrt(Math.pow(bb, 2) - (4 * ab * cb))) / (2 * ab);
            double d = (Math.sqrt(Math.pow(bb, 2) - (4 * ab * cb)));

            ca.setX1(answer1);
            ca.setX2(answer2);
            ca.setDelta(d);

            System.out.println("x1= " + ca.getX1() + " x2= " + ca.getX2());
        });
    }

}
