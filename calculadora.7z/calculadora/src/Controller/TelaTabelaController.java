/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Calculadora;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class TelaTabelaController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
     @FXML
    private TableColumn<Calculadora, Double> inicialc;

    @FXML
    private TableColumn<Calculadora, Double> finalc;

    @FXML
    private TableColumn<Calculadora, Double> resultadoc;

    @FXML
    private TableView<Calculadora> tablehistorico;

    @FXML
    private Button voltar;

    @FXML
    private TableColumn<Calculadora, Integer> idc;

    @FXML
    private TableColumn<Calculadora, String> equacaoc;

    @FXML
    private TableColumn<Calculadora, String> opec;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        voltar.setOnMouseClicked((MouseEvent evt)->{
            voltar();
        });
    } 
    
    public void voltar(){
        
    }
    
}
