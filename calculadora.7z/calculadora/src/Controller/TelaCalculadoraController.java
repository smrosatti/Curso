/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Calculadora;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author Aluno
 */
public class TelaCalculadoraController implements Initializable {          
    
    @FXML
    private Button bt3;

    @FXML
    private Button bt2;

    @FXML
    private Button bt5;

    @FXML
    private Button bt4;

    @FXML
    private Button bt7;

    @FXML
    private Button btvezes;

    @FXML
    private Button bt6;

    @FXML
    private Button btV;

    @FXML
    private Button bt9;

    @FXML
    private Button bt8;

    @FXML
    private ImageView imagem;

    @FXML
    private TextField lbn2;

    @FXML
    private Button btMenos;

    @FXML
    private Label label;

    @FXML
    private Button btHist;

    @FXML
    private TextField lbn1;

    @FXML
    private Button btMais;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private Button btD;

    @FXML
    private Button btIgual;

    @FXML
    private Button btapaga;

    @FXML
    private TextField tfres;

    @FXML
    private Button bt1;

    @FXML
    private Button bt0;

    private double n1;

    private double n2;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        buttons();

    }
    
    public void op(){
         btMais.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "1"); 
            n1 = Double.parseDouble(tfres.getText());
    });
    }

    public void buttons() {
     
        bt1.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "1"); 
            n1 = Double.parseDouble(tfres.getText());
    });
         bt2.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "2"); 
            n1 = Double.parseDouble(tfres.getText());
    });
          bt3.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "3"); 
            n1 = Double.parseDouble(tfres.getText());
    });
           bt4.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "4"); 
            n1 = Double.parseDouble(tfres.getText());
    });
            bt5.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "5"); 
            n1 = Double.parseDouble(tfres.getText());
    });
             bt6.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "6"); 
            n1 = Double.parseDouble(tfres.getText());
    });
              bt7.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "7"); 
            n1 = Double.parseDouble(tfres.getText());
    });
               bt8.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "8"); 
            n1 = Double.parseDouble(tfres.getText());
    });
                bt9.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "9"); 
            n1 = Double.parseDouble(tfres.getText());
    });
                 bt0.setOnMouseClicked((MouseEvent evt) -> {
           tfres.setText(tfres.getText()+ "0"); 
            n1 = Double.parseDouble(tfres.getText());
    });
       
    }

    public void somar() {
        try {
            Calculadora c = new Calculadora();
            double res = c.soma(n1, n2);
            tfres.setText(Double.toString(res));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
