/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Aluno
 */
public class Calculadora {

    private int id_conta;
    private double resultado;
    private double x1;
    private double x2;
    private double delta;
    private String detalhes;


    public double getX1() {
        return x1;
    }

    public void setX1(double x1) {
        this.x1 = x1;
    }

    public double getX2() {
        return x2;
    }

    public void setX2(double x2) {
        this.x2 = x2;
    }

    public double getDelta() {
        return delta;
    }

    public void setDelta(double delta) {
        this.delta = delta;
    }

    public int getId_conta() {
        return id_conta;
    }

    public void setId_conta(int id_conta) {
        this.id_conta = id_conta;
    }

    public double soma(double a, double b) {
        this.resultado = a + b;
        return resultado;
    }

    public double subtracao(double a, double b) {
        this.resultado = a - b;
        return resultado;
    }

    public double multiplicacao(double a, double b) {
        this.resultado = a * b;
        return resultado;
    }

    public double divisao(double a, double b) {
        this.resultado = a / b;
        return resultado;
    }

    public Calculadora equacaosegundograu(double a, double b, double c) {
        Calculadora calc = new Calculadora();
        String det = null;
        if (b > 0 && c > 0) {
            det = (a + "x^2 + " + b + "x + " + c + " =0");
        }
        if (b < 0 && c > 0) {
            det = (a + "x^2 " + b + "x + " + c + " =0");
        }
        if (b > 0 && c < 0) {
            det = (a + "x^2 + " + b + "x " + c + " =0");
        }
        if (b < 0 && c < 0) {
            det = (a + "x^2 " + b + "x " + c + " =0");
        }

        double answer1 = (-b + Math.sqrt(Math.pow(b, 2) - (4 * a * c))) / (2 * a);
        double answer2 = (-b - Math.sqrt(Math.pow(b, 2) - (4 * a * c))) / (2 * a);
        double d = (Math.sqrt(Math.pow(b, 2) - (4 * a * c)));

            
            calc.setX1(answer1);
            calc.setX2(answer2);
            calc.setDelta(d);
            calc.setDetalhes(det);

        return calc;
    }

    public String getDetalhes() {
        return detalhes;
    }

    public void setDetalhes(String detalhes) {
        this.detalhes = detalhes;
    }

    public double getResultado() {
        return resultado;
    }

    public void setResultado(double resultado) {
        this.resultado = resultado;
    }

}
