/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author Aluno
 */
public class BaskaraM extends Application {
    
    private static Stage stage;

    public static Stage getStage() {
        return stage;
    }

    public static void setStage(Stage stage) {
        BaskaraM.stage = stage;
    }
    
    @Override
    public void start(Stage primaryStage) throws IOException {
       Parent root = FXMLLoader.load(getClass().getResource("/View/Equacao.fxml"));
        
        Scene scene = new Scene(root);
        
        primaryStage.getIcons().add(new Image("/Imagem/icone.png"));
        primaryStage.setTitle("PUDIM - Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
        BaskaraM.setStage(primaryStage);
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
