/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Model.Calculadora;
import static java.lang.System.out;
import java.util.Scanner;

/**
 *
 * @author Aluno
 */
public class teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       /* Scanner pudim = new Scanner(System.in);
        System.out.println("n1");
        double n1 = pudim.nextDouble();
        System.out.println("n2");
        double n2 = pudim.nextDouble();
        Calculadora c = new Calculadora();
        System.out.println(c.soma(n1, n2));*/
         Scanner s = new Scanner(System.in);
    System.out.println("Insert value for a: ");
    double a = Double.parseDouble(s.nextLine());
    System.out.println("Insert value for b: ");
    double b = Double.parseDouble(s.nextLine());
    System.out.println("Insert value for c: ");
    double c = Double.parseDouble(s.nextLine());

    //Display format for negatives
    if (b > 0 && c > 0 ){
        System.out.println(a + "x^2 + " + b + "x + " + c + " =0");}
    if (b < 0 && c > 0 ){
        System.out.println(a + "x^2 " + b + "x + " + c + " =0");}
    if (b > 0 && c < 0 ){
        System.out.println(a + "x^2 + " + b + "x " + c + " =0");}
    if (b < 0 && c < 0 ){
        System.out.println(a + "x^2 " + b + "x " + c + " =0");}
    s.close();

    //The work/formula
    double answer1 = (-b + Math.sqrt(Math.pow(b, 2) - (4 * a * c))) / (2 * a);
    double answer2 = (-b - Math.sqrt(Math.pow(b, 2) - (4 * a * c))) / (2 * a);

    //Display results and check if the solution is imaginary (real or not)
    if (Double.isNaN(answer1) || Double.isNaN(answer2))
    {
        System.out.println("Answer contains imaginary numbers");
    } else System.out.println("The values are: " + answer1 + ", " + answer2);
}

}
